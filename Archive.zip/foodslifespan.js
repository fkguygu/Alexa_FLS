module.exports = {
  "FLS" : {
    "fish": "The shelf Life is no more than 2 days in the fridge. With Fresh Keep Smart Storage, it can be extened up to 4 days",
    "beef": "The shelf Life is no more than 2 days in the fridge. With Fresh Keep Smart Storage, it can be extened up to 4 days",
    "pork": "The shelf Life is no more than 2 days in the fridge. With Fresh Keep Smart Storage, it can be extened up to 4 days",
    "poultry": "the Shelf Life is no more than 2 days in the fridge. With Fresh Keep Smart Storage, it can be extened up to 4 days",
    "leftover cooked Meat": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "Cooked pork chops": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "holiday ham": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "smoked meat": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "cured meat": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "bacon": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "cottage cheese": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "cream cheese": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "blue cheese": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "Camembert": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "feta": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "soft cheese": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "stinky cheese": "The shelf life is no more than a week in the fridge. With Fresh Keep Smart Storage, it can be extened up to 10 days",
    "hard cheese": "The shelf life can be up to two months. With Fresh Keep Smart Storage, it can be extened up to 3 months",
    "cheddar": "The shelf life can be up to two months. With Fresh Keep Smart Storage, it can be extened up to 3 months",
    "parmesan": "The shelf life can be up to two months. With Fresh Keep Smart Storage, it can be extened up to 3 months",
    "ketchup": "The shelf life can be up to 8 months. With Fresh Keep Smart Storage, it can be extened up to 2 years",
    "mayo": "The shelf life can be up to 6 months. With Fresh Keep Smart Storage, it can be extened up to a year",
    "mustard": "The shelf life can be to for 8 months. With Fresh Keep Smart Storage, it can be extened up to a year"
  }
};
